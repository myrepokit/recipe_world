
// client-side script to support recipes and forms
async function loadRecipes() {
  const res = await fetch('assets/recipes.json');
  let base = await res.json();
  const extra = JSON.parse(localStorage.getItem('extraRecipes') || '[]');
  return base.concat(extra);
}
function el(sel){ return document.querySelector(sel); }
document.addEventListener('DOMContentLoaded', async () => {
  const recipes = await loadRecipes();
  if(el('#recipeList')){
    const list = el('#recipeList');
    list.innerHTML = '';
    recipes.forEach(r => {
      const item = document.createElement('div');
      item.className = 'recipe-item';
      item.innerHTML = `
        <img src="${r.image}" alt="${r.title}" role="button" data-id="${r.id}">
        <div>
          <h3><a href="recipe-detail.html?id=${r.id}">${r.title}</a></h3>
          <p>${r.description}</p>
        </div>
      `;
      list.appendChild(item);
    });
    const addForm = el('#addRecipeForm');
    if(addForm){
      addForm.addEventListener('submit', (ev)=>{
        ev.preventDefault();
        const id = 'r' + Date.now();
        const title = el('#newTitle').value.trim();
        const desc = el('#newDesc').value.trim();
        const ingredients = el('#newIngredients').value.trim().split('\n').map(s=>s.trim()).filter(Boolean);
        const directions = el('#newDirections').value.trim().split('\n').map(s=>s.trim()).filter(Boolean);
        const image = 'assets/img/magic.svg';
        const newR = {id,title,image,description:desc,ingredients,directions};
        const extras = JSON.parse(localStorage.getItem('extraRecipes') || '[]');
        extras.push(newR);
        localStorage.setItem('extraRecipes', JSON.stringify(extras));
        alert('Recipe added locally. Refresh to see it in the list.');
        addForm.reset();
      });
    }
    list.addEventListener('click', (ev)=>{
      const t = ev.target;
      if(t.tagName === 'IMG' && t.dataset.id){
        window.location.href = 'recipe-detail.html?id=' + encodeURIComponent(t.dataset.id);
      }
    });
  }
  if(el('#recipeDetail')){
    const params = new URLSearchParams(location.search);
    const id = params.get('id') || 'magic-cake';
    const r = recipes.find(x=>x.id===id);
    if(!r){ el('#recipeDetail').innerHTML = '<p>Recipe not found.</p>'; return; }
    el('#recipeTitle').textContent = r.title;
    el('#recipeImage').src = r.image;
    el('#recipeDesc').textContent = r.description;
    const ul = el('#ingredientsList'); ul.innerHTML='';
    r.ingredients.forEach(i=>{ const li=document.createElement('li'); li.textContent=i; ul.appendChild(li); });
    const ol = el('#directionsList'); ol.innerHTML='';
    r.directions.forEach(d=>{ const li=document.createElement('li'); li.textContent=d; ol.appendChild(li); });
  }
  if(el('#suggestForm')){
    const agree = el('#agree');
    const submit = el('#submitSuggest');
    submit.disabled = true;
    agree.addEventListener('change', ()=> submit.disabled = !agree.checked);
    el('#suggestForm').addEventListener('submit', (ev)=>{
      ev.preventDefault();
      const data = {
        recipeName: el('#sname').value,
        ingredients: el('#singredients').value,
        name: el('#syourname').value,
        email: el('#syouremail').value,
        ts: new Date().toISOString()
      };
      const arr = JSON.parse(localStorage.getItem('suggestions') || '[]');
      arr.push(data);
      localStorage.setItem('suggestions', JSON.stringify(arr));
      alert('Suggestion submitted. (Simulated email sent to instructor).\nThank you!');
      el('#suggestForm').reset();
      submit.disabled = true;
    });
  }
});
